<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  System.HealthCheckMenu
 *
 * @copyright   (C) 2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Plugin\System\HealthCheckMenu\Extension;

use Joomla\CMS\Event\Menu\PreprocessMenuItemsEvent;
use Joomla\CMS\Language\Text;
use Joomla\CMS\Menu\AdministratorMenuItem;
use Joomla\CMS\Plugin\CMSPlugin;
use Joomla\Event\SubscriberInterface;
use Joomla\Registry\Registry;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Adds a "Health Check" item to the Administrator sidebar menu.
 *
 * The default backend menu is preset-driven, so a database menu item never shows there. This plugin
 * injects the item at render time through the onPreprocessMenuItems event — the only extension point
 * for the preset menu that does not require editing core files. It reproduces the item the Health
 * Check feature would otherwise add to the core menu preset, linking to the cpanel dashboard the
 * Health Check module renders on.
 *
 * @since  6.2.0
 */
final class HealthCheckMenu extends CMSPlugin implements SubscriberInterface
{
    /**
     * Load the plugin language files automatically so the menu title translates.
     *
     * @var    boolean
     * @since  6.2.0
     */
    protected $autoloadLanguage = true;

    /**
     * The cpanel dashboard the Health Check module renders on.
     *
     * @var    string
     * @since  6.2.0
     */
    private const LINK = 'index.php?option=com_cpanel&view=cpanel&dashboard=healthcheck';

    /**
     * Whether the item has already been injected in this request.
     *
     * @var    boolean
     * @since  6.2.0
     */
    private bool $injected = false;

    /**
     * @inheritDoc
     *
     * @return  string[]
     *
     * @since   6.2.0
     */
    public static function getSubscribedEvents(): array
    {
        return [
            'onPreprocessMenuItems' => 'onPreprocessMenuItems',
        ];
    }

    /**
     * Append the Health Check item to the top level of the Administrator sidebar menu.
     *
     * The event fires once per menu level; the first pass for the main backend menu is the top
     * level, so the item is added there and a guard prevents it being repeated at deeper levels.
     *
     * @param   PreprocessMenuItemsEvent  $event  The event.
     *
     * @return  void
     *
     * @since   6.2.0
     */
    public function onPreprocessMenuItems(PreprocessMenuItemsEvent $event): void
    {
        if ($this->injected) {
            return;
        }

        // Only touch the main Administrator sidebar menu, not mod_submenu or other contexts.
        if ($event->getContext() !== 'com_menus.administrator.module') {
            return;
        }

        $items = $event->getItems();

        if (empty($items)) {
            return;
        }

        // Never add a duplicate if the item is already present (e.g. core preset provides it).
        foreach ($items as $existing) {
            if (isset($existing->link) && $existing->link === self::LINK) {
                $this->injected = true;

                return;
            }
        }

        /*
         * The menu renders from the parent node's children, but the event only hands us a copy of
         * that array. Reach the parent through an existing sibling and attach the new item to the
         * node itself so it is actually rendered.
         */
        $parent = reset($items)->getParent();

        if ($parent === null) {
            return;
        }

        $item          = new AdministratorMenuItem();
        $item->id      = 'healthcheck';
        $item->type    = 'component';
        $item->title   = 'PLG_SYSTEM_HEALTHCHECKMENU_MENU_TITLE';
        $item->text    = Text::_('PLG_SYSTEM_HEALTHCHECKMENU_MENU_TITLE');
        $item->link    = self::LINK;
        $item->element = 'com_cpanel';
        $item->class   = 'class:heart';
        $item->scope   = 'default';
        $item->access  = 0;
        $item->setParams(new Registry());

        $parent->addChild($item);

        $this->injected = true;
    }
}
