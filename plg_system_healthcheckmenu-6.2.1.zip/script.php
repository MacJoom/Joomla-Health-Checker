<?php

/**
 * @package     Joomla.Plugin
 * @subpackage  System.HealthCheckMenu
 *
 * @copyright   (C) 2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Installation script for plg_system_healthcheckmenu.
 *
 * Enables the plugin on install so the Administrator sidebar link appears without the user having
 * to publish it manually (system plugins install disabled by default).
 *
 * @since  6.2.0
 */
return new class () implements InstallerScriptInterface, DatabaseAwareInterface {
    use DatabaseAwareTrait;

    /**
     * Called after the extension is installed.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the extension is updated.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the extension is uninstalled.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called before the install/update/uninstall procedure commences.
     *
     * @param   string            $type     The type of change (install, update, ...).
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the install/update/uninstall procedure commences.
     *
     * @param   string            $type     The type of change (install, update, ...).
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if (!\in_array($type, ['install', 'discover_install'], true)) {
            return true;
        }

        try {
            $db      = $this->getDatabase();
            $folder  = 'system';
            $element = 'healthcheckmenu';

            $query = $db->getQuery(true)
                ->update($db->quoteName('#__extensions'))
                ->set($db->quoteName('enabled') . ' = 1')
                ->where($db->quoteName('type') . ' = ' . $db->quote('plugin'))
                ->where($db->quoteName('folder') . ' = :folder')
                ->where($db->quoteName('element') . ' = :element')
                ->bind(':folder', $folder, ParameterType::STRING)
                ->bind(':element', $element, ParameterType::STRING);
            $db->setQuery($query)->execute();
        } catch (\Throwable $e) {
            // Non-fatal: the user can enable the plugin manually if this fails.
        }

        return true;
    }
};
