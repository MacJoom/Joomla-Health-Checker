<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  mod_healthcheck
 *
 * @copyright   (C) 2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

use Joomla\CMS\Factory;
use Joomla\CMS\Installer\InstallerAdapter;
use Joomla\CMS\Installer\InstallerScriptInterface;
use Joomla\CMS\Language\Text;
use Joomla\Database\DatabaseAwareInterface;
use Joomla\Database\DatabaseAwareTrait;
use Joomla\Database\ParameterType;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Installation script for mod_healthcheck.
 *
 * Provisions, on install/update, a published module instance in the "cpanel-healthcheck" dashboard
 * position so the Health Check dashboard has something to render. The item is created only when
 * missing, so re-running is safe. The Administrator sidebar link is handled separately by the
 * companion plg_system_healthcheckmenu plugin (the preset-driven backend menu cannot be extended
 * from a module).
 *
 * @since  6.2.0
 */
return new class () implements InstallerScriptInterface, DatabaseAwareInterface {
    use DatabaseAwareTrait;

    /**
     * The module position rendered by the "healthcheck" cpanel dashboard.
     *
     * @var    string
     * @since  6.2.0
     */
    private const POSITION = 'cpanel-healthcheck';

    /**
     * Called after the extension is installed.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function install(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the extension is updated.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function update(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the extension is uninstalled.
     *
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function uninstall(InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called before the install/update/uninstall procedure commences.
     *
     * @param   string            $type     The type of change (install, update, ...).
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function preflight(string $type, InstallerAdapter $adapter): bool
    {
        return true;
    }

    /**
     * Called after the install/update/uninstall procedure commences.
     *
     * @param   string            $type     The type of change (install, update, ...).
     * @param   InstallerAdapter  $adapter  The adapter calling this method.
     *
     * @return  boolean
     *
     * @since   6.2.0
     */
    public function postflight(string $type, InstallerAdapter $adapter): bool
    {
        if (\in_array($type, ['install', 'discover_install', 'update'], true)) {
            $this->provisionModule();
        }

        return true;
    }

    /**
     * Create a published module instance in the cpanel-healthcheck position, unless one already
     * exists there.
     *
     * @return  void
     *
     * @since   6.2.0
     */
    private function provisionModule(): void
    {
        try {
            $db       = $this->getDatabase();
            $module   = 'mod_healthcheck';
            $position = self::POSITION;

            $query = $db->getQuery(true)
                ->select($db->quoteName('id'))
                ->from($db->quoteName('#__modules'))
                ->where($db->quoteName('module') . ' = :module')
                ->where($db->quoteName('client_id') . ' = 1')
                ->where($db->quoteName('position') . ' = :position')
                ->bind(':module', $module, ParameterType::STRING)
                ->bind(':position', $position, ParameterType::STRING);
            $db->setQuery($query);

            if ($db->loadResult()) {
                return;
            }

            $record = (object) [
                'title'     => 'Health Check',
                'note'      => '',
                'ordering'  => 0,
                'position'  => self::POSITION,
                'published' => 1,
                'module'    => 'mod_healthcheck',
                'access'    => 1,
                'showtitle' => 1,
                'params'    => '{"context":"general"}',
                'client_id' => 1,
                'language'  => '*',
            ];

            $db->insertObject('#__modules', $record, 'id');

            // Assign the module to all administrator pages (menuid 0).
            $assignment = (object) ['moduleid' => (int) $record->id, 'menuid' => 0];
            $db->insertObject('#__modules_menu', $assignment);
        } catch (\Throwable $e) {
            Factory::getApplication()->getLanguage()->load('mod_healthcheck', JPATH_ADMINISTRATOR);
            Factory::getApplication()->enqueueMessage(
                trim(Text::_('MOD_HEALTHCHECK_INSTALL_MODULE_FAILED') . ' ' . $e->getMessage()),
                'warning'
            );
        }
    }
};
