<?php

/**
 * @package     Joomla.Administrator
 * @subpackage  mod_healthcheck
 *
 * @copyright   (C) 2026 Open Source Matters, Inc. <https://www.joomla.org>
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 */

namespace Joomla\Module\Healthcheck\Administrator\HtmlHelper;

use Joomla\CMS\Factory;
use Joomla\CMS\Layout\FileLayout;

// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects

/**
 * Self-contained HTMLHelper service for the Health Check module.
 *
 * This mirrors the core \Joomla\CMS\HTML\Helpers\HealthChecks service so the
 * module can render on a stock Joomla install that does not ship the core
 * helper. It is registered under the "healthchecks" HTMLHelper key by the
 * module dispatcher, but only when the core service is not already present, so
 * on a site that provides the core helper this class is never invoked.
 *
 * Unlike the core service it resolves its layouts from the module's own
 * layouts folder rather than the global joomla.healthchecks layout path.
 *
 * @since  6.2.0
 */
abstract class HealthChecks
{
    /**
     * Base path for the module-owned health check layouts.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    private static function basePath(): string
    {
        return JPATH_ADMINISTRATOR . '/modules/mod_healthcheck/layouts';
    }

    /**
     * Render a single layout for one item.
     *
     * @param   string  $layout  The layout id inside the module layouts folder.
     * @param   array   $item    The item data.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    private static function render(string $layout, $item): string
    {
        if (!static::canAccess($item)) {
            return '';
        }

        return (new FileLayout($layout, static::basePath()))->render($item);
    }

    /**
     * Generate html code for a list of gauges.
     *
     * @param   array  $gauges  Array of gauges.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function gauges($gauges)
    {
        if (empty($gauges)) {
            return '';
        }

        $html = [];

        foreach ($gauges as $gauge) {
            $html[] = static::gauge($gauge);
        }

        return implode($html);
    }

    /**
     * Generate html code for a gauge.
     *
     * @param   array  $gauge  Gauge properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function gauge($gauge)
    {
        return static::render('gauge', $gauge);
    }

    /**
     * Generate html code for a list of buttons.
     *
     * @param   array  $buttons  Array of buttons.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function buttons($buttons)
    {
        if (empty($buttons)) {
            return '';
        }

        $html = [];

        foreach ($buttons as $button) {
            $html[] = static::button($button);
        }

        return implode($html);
    }

    /**
     * Generate html code for a button.
     *
     * @param   array  $button  Button properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function button($button)
    {
        return static::render('icon', $button);
    }

    /**
     * Generate html code for a list of tables.
     *
     * @param   array  $tables  Array of tables.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function tables($tables)
    {
        if (empty($tables)) {
            return '';
        }

        $html = [];

        foreach ($tables as $table) {
            $html[] = static::table($table);
        }

        return implode($html);
    }

    /**
     * Generate html code for a table.
     *
     * @param   array  $table  Table properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function table($table)
    {
        return static::render('table', $table);
    }

    /**
     * Generate html code for a list of lists.
     *
     * @param   array  $lists  Array of lists.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function lists($lists)
    {
        if (empty($lists)) {
            return '';
        }

        $html = [];

        foreach ($lists as $list) {
            $html[] = static::list($list);
        }

        return implode($html);
    }

    /**
     * Generate html code for a list.
     *
     * @param   array  $list  List properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function list($list)
    {
        return static::render('list', $list);
    }

    /**
     * Generate html code for a set of leading information.
     *
     * @param   array  $leadings  Array of leading information.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function leadings($leadings)
    {
        if (empty($leadings)) {
            return '';
        }

        $html = [];

        foreach ($leadings as $leading) {
            $html[] = static::leading($leading);
        }

        return implode($html);
    }

    /**
     * Generate html code for leading information.
     *
     * @param   array  $leading  Leading properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function leading($leading)
    {
        return static::render('leading', $leading);
    }

    /**
     * Generate html code for a set of footer information.
     *
     * @param   array  $footers  Array of footer information.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function footers($footers)
    {
        if (empty($footers)) {
            return '';
        }

        $html = [];

        foreach ($footers as $footer) {
            $html[] = static::footer($footer);
        }

        return implode($html);
    }

    /**
     * Generate html code for footer information.
     *
     * @param   array  $footer  Footer properties.
     *
     * @return  string
     *
     * @since   6.2.0
     */
    public static function footer($footer)
    {
        return static::render('footer', $footer);
    }

    /**
     * Check if an item can be accessed based on access permissions.
     *
     * @param   array  $item  Item with access properties.
     *
     * @return  bool  True if access is allowed, false otherwise.
     *
     * @since   6.2.0
     */
    protected static function canAccess($item)
    {
        if (!isset($item['access'])) {
            return true;
        }

        if (\is_bool($item['access'])) {
            return $item['access'];
        }

        // Get the user object to verify permissions
        $user = Factory::getApplication()->getIdentity();

        // Take each pair of permission, context values.
        for ($i = 0, $n = \count($item['access']); $i < $n; $i += 2) {
            if (!$user->authorise($item['access'][$i], $item['access'][$i + 1])) {
                return false;
            }
        }

        return true;
    }
}
